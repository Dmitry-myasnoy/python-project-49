#!/usr/bin/env python3

def main():
    print("Hello, Brain Games!")

if __name__ == "__main__":
    main()
    
